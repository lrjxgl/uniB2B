<template>
	<view>
		<view class="unLoginBox">
			<view class="flex flex-center mgb-20 cl2">您还未登录,请先登录</view>
			<view class="flex flex-center">
				<navigator class="btn-small" url="../../pages/login/index">前往登录</navigator>
			</view>
		</view>
	</view>
</template>

<script>
</script>

<style>
</style>
